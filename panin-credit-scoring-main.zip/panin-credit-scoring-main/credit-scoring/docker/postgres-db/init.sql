CREATE DATABASE ai_credit_scoring;
CREATE DATABASE ai_mlflow;